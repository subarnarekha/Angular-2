import {Injectable} from '@angular/core'
import {employees} from '../DB/employees'
import {IEmployee} from '../Models/IEmployee'

@Injectable()
export class EmployeeService{
    getEmployees():IEmployee[]{
        return employees;
    }
     getEmployeeById(id:number):IEmployee[]{
        return employees.filter((emp)=> emp.empId == id);
        
    }
     getEmployeeByName(name:string):IEmployee[]{
        return employees.filter((emp) => emp.empName.toLowerCase() == name.toLowerCase());
    }
}

