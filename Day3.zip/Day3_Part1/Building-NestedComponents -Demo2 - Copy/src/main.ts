import { BrowserModule } from '@angular/platform-browser';
import { Component,enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { EmpComponent } from './employee.component';
import { AccountComponent } from './acc.component';
import { StudComponent } from './stud.component';
import { DispComponent } from './disp.component';

enableProdMode();
@Component({
  selector: 'my-app',
  template: `<div>  
			  <h1>Calling Child from 3 parents</h1>
			  <emp-parent> </emp-parent>
			  <account-parent> </account-parent>
			  <stud-parent> </stud-parent>
			 </div> `

})
export class MainComponent {
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ MainComponent,EmpComponent,AccountComponent,StudComponent,DispComponent ],
  bootstrap:[ MainComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  
