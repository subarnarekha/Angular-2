import { Component } from '@angular/core';
import { DispComponent } from './disp.component';
import { Employee } from './employee';

@Component({
  selector: 'emp-parent',
  template: `<div>  
			  <h1>I'm Employee component - Calling Display Component</h1>
			  <child-selector 
				  [data]='employees' 
				  [type]='t'>
			  </child-selector>
			 </div>  <hr/>`

})
export class EmpComponent {
t:string;
employees:Employee[];
constructor()
{
   this.employees=[  
             { id: 101, name: 'Virat Kholi',desig:'TL' },    
             { id: 102, name: 'Yuvraj Singh',desig:'TL' },    
			 { id: 104, name: 'MS Dhoni',desig:'SSE' }   		 
           ];
    this.t="emp"
 }
} 