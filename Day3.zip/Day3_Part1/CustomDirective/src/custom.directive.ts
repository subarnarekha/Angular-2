import { Directive,HostBinding,HostListener } from '@angular/core';

@Directive({
  selector: '[myDirective]'
})

export class CustomDirective {
	@HostBinding('attr.role') role;
	
	 @HostListener('click', ['$event'])
	 onClick(e:any) {
	   if(this.role=="guest")
	    { this.role="admin";
		 }
		 else
	   this.role="guest";
		//this.role=this.role=="guest"?"admin":"guest";
		e.target.innerText =this.role;
	}
}
