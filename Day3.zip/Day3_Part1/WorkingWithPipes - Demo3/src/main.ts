import { Component,NgModule,enableProdMode  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

@Component({
  selector: 'my-app',
  template: `
	    <h2>Async Pipe Example</h2>
	    <h2>wait... {{promise | async}} </h2> 
		 <h2>wait... {{p1 | async}} </h2> 
		<h1> Search {{name | async}}</h1>
	    <button (click)="clickMe()">Click me to initiate promise</button>
	    `
}) 
export class AsyncPipe {
	promise : Promise <string> = null;
	p1 : Promise <string> = null;
	name:string="Google";
	clickMe() {
		this.promise = new Promise<string>((resolve, reject) => {
			setTimeout(function () {
				resolve("Welcome to Capgemini...");
			},2000);
		});
		this.p1 = new Promise<string>((resolve, reject) => {
			setTimeout(function () {
				resolve("Thank You...");
			},8000);
		});
	}
}
@NgModule({
	imports:[ BrowserModule ],
	declarations:[ AsyncPipe ],
	bootstrap:[ AsyncPipe ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  