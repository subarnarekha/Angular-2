import { Component,Directive } from '@angular/core';
@Directive({
  selector: 'comp'
})
export class SomeDirective {
}

@Component({
  selector: 'comp',
  template: `
    <div>Component template</div>
  `
})
export class SomeComponent {
}


