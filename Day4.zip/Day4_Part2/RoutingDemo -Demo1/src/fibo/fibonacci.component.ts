import { Component,Injectable,Inject } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  template: `<div>
	<h1>Fibonacci series</h1>
	<h2>{{series}}</h2>
	<hr/>
	<input type="submit" (click)='generate()' value="Submit"/>
	<input type="submit" (click)='goToHome()' value="Go To Home"/>
  <div>`
})
export class SeriesComponent {
	series:string="";
	first:number=0;
	second:number=1;
	 constructor(@Inject(Router) private router:Router){
         
    }
	generate() {
		var next=this.first+this.second;
	    this.series+=next+" ";
		this.first=this.second;
		this.second=next;
	};
	
	goToHome() {
	this.router.navigate(['/home']);
	}
}
