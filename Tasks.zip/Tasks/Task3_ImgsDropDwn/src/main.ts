import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();


@Component({
   selector: 'my-app';
   template:`
	<h1> {{t1}}</h1>
	Choose your IPL Team:
	<select [(ngModel)]="country">
	<option value="">--Select--</option>
	 <option value="images/download (1).jpg">Kolkata</option>
	 <option value="images/download (2).jpg">Rajasthan</option>
	 <option value="images/download (3).jpg">Delhi</option>
	 <option value="images/download.jpg">Chennai</option>
	</select>
	<hr/>
	<h1> <img src="{{country}}"></h1>
   `
})

export class AppComponent {
 t1:string="Welcome";
 country:string="";
}

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
