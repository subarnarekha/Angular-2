import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
enableProdMode();

interface Student{
    id:number,
    name:string,
    desig:string
}


@Component({
  selector: 'my-app',
  template:
  `<h1>Enter an Student id</h1>
<input type="text" [(ngModel)]="sid"/>
<br/>
<input type="button" (click)="getDetails()" value="Load"/><br/>
<hr/>
<h1> Details</h1>
<table class="table table-striped" *ngIf="show">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Desig</th>
        </tr>
    </thead>
    <tbody>
         <tr>
              <td>{{ s.id }}</td>
              <td>{{ s.name }}</td>
              <td>{{ s.desig }}</td>
          </tr>
     </tbody>
</table>`
})
class GuestComponent implements OnInit{
   private studs:Student[];
   studs= [  
	 { "id": 1, "name": "Ram","desig":"TL" },    
	 { "id": 2, "name": "Ravan","desig":"SSE" },    
	 { "id": 3, "name": "Lakshman","desig":"TL" },   
	 { "id": 4, "name": "Krish","desig":"TL" },    
	 		 
  ];
  sid:number=0;
  show:boolean=false;
  s:Student;
  getDetails()
  {
	this.show=true;
	for(let i=0;i<(this.studs).length;i++)
	{
	if((this.studs[i]).id==this.sid)
	this.s=this.studs[i];
	}
  }
}

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

  