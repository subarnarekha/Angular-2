import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<input type="submit" (click)='showValue()' value="Next Number"/>
	<hr/>
	<h1>{{fib}}</h1>
	<br/>
	<h1>A new Component invoked</h1>
  <div>`
})
export class FibComponent {
	a:number=1;
	b:number=0;
	fib:number=0;
	onKey(event:any) {
	    this.show=false;
		this.values = event.target.value;
	};
	showValue():number {
	    this.fib=this.a+this.b;
		this.a=this.b;
		this.b=this.fib;
		return fib;
		
	};
}


@NgModule({
	imports:[ BrowserModule ],
	declarations:[ FibComponent],
	bootstrap:[ FibComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);