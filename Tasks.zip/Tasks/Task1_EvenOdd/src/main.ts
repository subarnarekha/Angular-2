import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<h1>Enter a number</h1>
	<input type="text" (keyup)='onKey($event)'/>
	<hr/>
	
	<h1> {{result}}</h1>
	
	<hr/>
  <div>`
})
export class EvenOddComponent {
	values:string="";

	result:string;
	onKey(event:any) {
		this.values = event.target.value;
		if(this.values%2==0)
	    this.result="EVEN";
		else
		this.result="ODD";
	};

}


@NgModule({
	imports:[ BrowserModule ],
	declarations:[ EvenOddComponent],
	bootstrap:[ EvenOddComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);