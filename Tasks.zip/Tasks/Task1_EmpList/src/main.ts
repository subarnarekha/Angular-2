import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
enableProdMode();

interface Student{
    id:number,
    name:string,
    dept:string
}


@Component({
  selector: 'my-app',
  template:
  `
<br/>
<input type="button" (click)="getDetails()" value="Load"/><br/>
<hr/>
<h1>Student Details</h1>
<table class="table table-striped" *ngIf="show">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Dept</th>
        </tr>
    </thead>
    <tbody>
         <tr *ngFor="let s of studs">
              <td >{{ s.id }}</td>
			<td >{{ s.name }}</td>
			<td >{{ s.dept }}</td>
          </tr>
     </tbody>
</table>`
})


class GuestComponent implements OnInit{
   private studs:Student[];
   studs= [  
	 { "id": 1, "name": "Ram","dept":"CSE" },    
	 { "id": 2, "name": "Ravan","dept":"IT" },    
	 { "id": 3, "name": "Lakshman","dept":"CSE" },   
	 { "id": 4, "name": "Krish","dept":"ECE" },    
	 		 
  ];
  sid:number=0;
  show:boolean=false;
  s:Student;
  getDetails()
  {
	this.show=true;
	for(let i=0;i<(this.studs).length;i++)
	{
	if((this.studs[i]).id==this.sid)
	this.s=this.studs[i];
	}
  }
}

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

  